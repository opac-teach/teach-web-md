import ThreeApp from "@/app/three-app";

export default function Home() {
    return (
        <div className="flex min-h-screen items-center justify-center bg-zinc-50 font-sans dark:bg-black">
            <main
                className="flex min-h-screen w-full max-w-3xl flex-col gap-16 py-32 px-16 bg-white dark:bg-black">
                <p className="text-4xl font-bold">
                    Hello, Three.js
                </p>
                <div className="w-full h-128">
                    <ThreeApp/>
                </div>
            </main>
        </div>
    );
}
