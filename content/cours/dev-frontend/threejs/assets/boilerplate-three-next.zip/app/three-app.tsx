"use client"

import {useEffect, useRef} from "react";
import {Game} from '@/game'

export default function ThreeApp() {
    const containerRef = useRef<HTMLDivElement>(null);
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const gameRef = useRef<Game>(null);

    useEffect(() => {
        const container = containerRef.current;
        const canvas = canvasRef.current;
        if (!container || !canvas || gameRef.current) return;


        const {width, height} = container.getBoundingClientRect();
        gameRef.current = new Game(canvas, width, height);

        const observer = new ResizeObserver((entries) => {
            const {width, height} = entries[0].contentRect;
            gameRef.current?.resize(width, height);
        });
        observer.observe(container);

        return () => {
            observer.disconnect();
            gameRef.current?.dispose();
        };
    }, [])

    return (
        <div ref={containerRef} className="w-full h-full">
            <canvas ref={canvasRef}/>
        </div>
    );
}
