import * as THREE from "three";

export class Game {
    scene: THREE.Scene
    camera: THREE.PerspectiveCamera
    renderer: THREE.WebGLRenderer
    objects: Record<string, THREE.Object3D> = {}
    lights: Record<string, THREE.Light> = {}
    lastFrameTime: number = 0

    constructor(canvas: HTMLCanvasElement, width: number, height: number) {
        // Create scene, camera, and renderer
        this.scene = new THREE.Scene();

        this.camera = new THREE.PerspectiveCamera(
            75,
            width / height,
            0.1,
            1000
        );

        this.renderer = new THREE.WebGLRenderer({
            antialias: true,
            canvas
        });
        this.renderer.setSize(width, height);

        // Create a cube
        const geometry = new THREE.BoxGeometry(1, 1, 1); // Create the geometry of the cube
        const material = new THREE.MeshStandardMaterial({color: 0x00ff00}); // Create the material of the cube
        this.objects.cube = new THREE.Mesh(geometry, material); // Create the object of the cube with the geometry and material
        this.scene.add(this.objects.cube); // Add cube to the scene

        this.objects.cube.position.x = 0; // Set the position of the cube
        this.camera.position.z = 5; // Set the position of the camera

        // Create a light
        this.lights.directional = new THREE.DirectionalLight(0xffffff, 5); // Create the light
        this.lights.directional.position.set(1, 2, 10);// Set the position of the light
        (this.lights.directional as THREE.DirectionalLight).target = this.objects.cube; // Set the target of the light to the cube
        this.scene.add(this.lights.directional); // Add the light to the scene

        // Ask the browser to call the animate function every frame
        this.renderer.setAnimationLoop(this.animate.bind(this));
    }

    // Animation loop, executed every frame
    animate(timeElapsedSinceBeginning: number) {
        // Check how much time has passed since the last frame
        const timeElapsedSinceLastFrame = (timeElapsedSinceBeginning - this.lastFrameTime) / 1000; // Convert to seconds
        this.lastFrameTime = timeElapsedSinceBeginning;

        this.objects.cube.position.x += 0.4 * timeElapsedSinceLastFrame; // Move cube in the x direction
        this.objects.cube.rotation.y += 0.4 * timeElapsedSinceLastFrame; // Rotate cube in the y axis

        if (this.objects.cube.position.x > 4) this.objects.cube.position.x = -4; // Reset cube position if it goes beyond the screen

        this.renderer.render(this.scene, this.camera); // Render the scene
    }

    resize(w: number, h: number) {
        this.camera.aspect = w / h;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(w, h);
    }

    dispose() {
        this.renderer.setAnimationLoop(null);
        this.renderer.dispose();
    }
}

