#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "Annuaire.hpp"

void Annuaire::add(const std::string &nom, const std::string &numero)
{
}