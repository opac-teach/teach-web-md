#include <iostream>
#include <string>
#include <cassert>
#include <fstream>
#include "Annuaire.hpp"

void test()
{
    std::cout << "Tests" << std::endl;

    Annuaire annuaire;

    /*
    assert(!annuaire.exists("alice"));
    annuaire.add("alice", "0612345678");

    assert(annuaire.exists("alice"));
    auto res = annuaire.get("alice");
    assert(res.first == "alice");
    assert(res.second == "0612345678");

    assert(!annuaire.exists("bob"));
    annuaire.add("bob", "128192381");
    assert(annuaire.exists("bob"));
    annuaire.remove("bob");
    assert(!annuaire.exists("bob"));
    */

    std::cout << "Tests OK" << std::endl;
}

void ui()
{
    Annuaire annuaire;
    std::string command;

    while (true)
    {
        std::cout << "Que voulez vous faire ?" << std::endl;
        std::cout << "(a : ajouter l: afficher q: quitter)" << std::endl;
        std::cout << "> ";
        std::getline(std::cin, command);

        if (command == "a")
        {
            // annuaire.add(...)
        }
        else if (command == "l")
        {
        }
        else if (command == "q")
        {
        }
        else
        {
            std::cout << "Commande inconnue" << std::endl;
        }
    }
}

int main()
{
    test();
    ui();
    return 0;
}