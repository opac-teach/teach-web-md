# boilerplate-mongo

This is an example project for using mongo with node.js

## Prerequisites

- NodeJS
- Docker for running mongo server (or a cloud database on Atlas)

## Setup

- Install dependencies

```bash
npm i
```

- Start server

```bash
docker-compose up -d
```

- Setup environment variables

Copy `.env.example`to `.env` and change accordingly to your setup (not needed if using default docker config)

- Seed database

```js
node src/seed.js
```

## Running

- Run example program

```js
node src/index.js
```

## Cleaning

If you need to cleanup the database, you can either wipe collections by using `collection.deleteMany({})`, or clear the docker volume and restarting it:

```bash
docker compose down -v
docker compose up -d
```