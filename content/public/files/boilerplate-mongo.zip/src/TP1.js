// TP 1

// Exercice 1.1

// TODO ...