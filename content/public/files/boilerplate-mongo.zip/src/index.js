import { db, client } from "./db.js";

// Get "films" collection
const films = db.collection("films")

// Get all films in "films" collection
const result = await films.find({}).toArray()
console.log(result)

// Close the connection so the program can stop (otherwise the process will run forever)
await client.close()
