import express  from 'express';
import {ObjectId} from "mongodb";
import {db} from './db.js'

const app = express()
const port = 3000

app.get('/', (req, res) => {
    res.send('Hello World!')
})

const films = db.collection("films")

app.get('/films', async (req, res) => {
    const limit = req.query.limit ? Number(req.query.limit) : 10;
    const skip = req.query.skip ? Number(req.query.skip) : 0;
    const result = await films.find({}).limit(limit).skip(skip || 0).toArray()

    res.send(result)
})

app.get('/films/:id', async (req, res) => {
    if(!ObjectId.isValid(req.params.id)) return res.status(400).send()

    const result = await films.findOne({_id: new ObjectId(req.params.id)})

    if(!result) return res.status(404).send(
        {
            error: "Film not found"
        }
    )

    res.send(result)
})

app.listen(port, () => {
    console.log(`App listening on port ${port}`)
})
