import 'dotenv/config';
import { MongoClient } from "mongodb";

const uri = process.env.MONGODB_URI;

const client = new MongoClient(uri);

await client.connect()
console.log("Connected successfully to server")
const db = client.db("streaming")

export { client, db };
