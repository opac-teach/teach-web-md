import { db, client } from "./db.js";

const films = db.collection("films")
const utilisateurs = db.collection("utilisateurs")
const visionnages = db.collection("visionnages")

await films.insertMany([
    {
        titre: "Inception",
        annee: 2010,
        genres: ["sci-fi", "thriller", "action"],
        realisateur: "Christopher Nolan",
        note: 8.8,
        duree: 148,
        langues: ["anglais", "japonais", "français"],
    },
    {
        titre: "The Dark Knight",
        annee: 2008,
        genres: ["action", "crime", "drame"],
        realisateur: "Christopher Nolan",
        note: 9.0,
        duree: 152,
        langues: ["anglais"],
    },
    {
        titre: "Parasite",
        annee: 2019,
        genres: ["thriller", "drame", "comédie noire"],
        realisateur: "Bong Joon-ho",
        note: 8.6,
        duree: 132,
        langues: ["coréen"],
    },
    {
        titre: "Interstellar",
        annee: 2014,
        genres: ["sci-fi", "aventure", "drame"],
        realisateur: "Christopher Nolan",
        note: 8.7,
        duree: 169,
        langues: ["anglais"],
    },
    {
        titre: "Pulp Fiction",
        annee: 1994,
        genres: ["crime", "drame"],
        realisateur: "Quentin Tarantino",
        note: 8.9,
        duree: 154,
        langues: ["anglais", "espagnol", "français"],
    },
    {
        titre: "The Grand Budapest Hotel",
        annee: 2014,
        genres: ["comédie", "aventure", "drame"],
        realisateur: "Wes Anderson",
        note: 8.1,
        duree: 99,
        langues: ["anglais", "français", "allemand"],
    },
    {
        titre: "Oldboy",
        annee: 2003,
        genres: ["thriller", "drame", "mystère"],
        realisateur: "Park Chan-wook",
        note: 8.4,
        duree: 120,
        langues: ["coréen"],
    },
    {
        titre: "Mad Max: Fury Road",
        annee: 2015,
        genres: ["action", "aventure", "sci-fi"],
        realisateur: "George Miller",
        note: 8.1,
        duree: 120,
        langues: ["anglais"],
    },
])

await utilisateurs.insertMany([
    {
        nom: "Alice Martin",
        email: "alice@example.com",
        age: 28,
        abonnement: "premium",
        dateInscription: new Date("2022-03-15"),
        preferences: {
            genres: ["sci-fi", "thriller"],
            realisateurs: ["Christopher Nolan", "Denis Villeneuve"],
        },
    },
    {
        nom: "Bob Dupont",
        email: "bob@example.com",
        age: 35,
        abonnement: "standard",
        dateInscription: new Date("2021-11-02"),
        preferences: {
            genres: ["action", "crime"],
            realisateurs: ["Quentin Tarantino"],
        },
    },
    {
        nom: "Claire Leroy",
        email: "claire@example.com",
        age: 22,
        abonnement: "basic",
        dateInscription: new Date("2023-01-20"),
        preferences: {
            genres: ["drame", "comédie"],
            realisateurs: ["Wes Anderson", "Bong Joon-ho"],
        },
    },
    {
        nom: "David Chen",
        email: "david@example.com",
        age: 41,
        abonnement: "premium",
        dateInscription: new Date("2020-07-08"),
        preferences: {
            genres: ["thriller", "drame"],
            realisateurs: ["Park Chan-wook", "Bong Joon-ho"],
        },
    },
    {
        nom: "Emma Blanc",
        email: "emma@example.com",
        age: 19,
        abonnement: "basic",
        dateInscription: new Date("2023-09-01"),
        preferences: {
            genres: ["action", "sci-fi"],
            realisateurs: ["George Miller"],
        },
    },
])

const alice = (await utilisateurs.findOne({ email: "alice@example.com" }))._id
const bob = (await utilisateurs.findOne({ email: "bob@example.com" }))._id
const claire = (await utilisateurs.findOne({ email: "claire@example.com" }))._id
const david = (await utilisateurs.findOne({ email: "david@example.com" }))._id
const emma = (await utilisateurs.findOne({ email: "emma@example.com" }))._id

const inception = (await films.findOne({ titre: "Inception" }))._id
const darkKnight = (await films.findOne({ titre: "The Dark Knight" }))._id
const parasite = (await films.findOne({ titre: "Parasite" }))._id
const interstellar = (await films.findOne({ titre: "Interstellar" }))._id
const pulpFiction = (await films.findOne({ titre: "Pulp Fiction" }))._id
const grandBudapest = (await films.findOne({ titre: "The Grand Budapest Hotel" }))._id
const oldboy = (await films.findOne({ titre: "Oldboy" }))._id
const madMax = (await films.findOne({ titre: "Mad Max: Fury Road" }))._id

await visionnages.insertMany([
    { utilisateurId: alice, filmId: inception,     date: new Date("2024-01-10"), noteUtilisateur: 9,    termine: true  },
    { utilisateurId: alice, filmId: interstellar,  date: new Date("2024-01-15"), noteUtilisateur: 8,    termine: true  },
    { utilisateurId: alice, filmId: parasite,      date: new Date("2024-02-03"), noteUtilisateur: 9,    termine: true  },
    { utilisateurId: bob,   filmId: darkKnight,    date: new Date("2024-01-20"), noteUtilisateur: 10,   termine: true  },
    { utilisateurId: bob,   filmId: pulpFiction,   date: new Date("2024-02-14"), noteUtilisateur: 9,    termine: true  },
    { utilisateurId: bob,   filmId: inception,     date: new Date("2024-03-01"), noteUtilisateur: 8,    termine: true  },
    { utilisateurId: claire, filmId: grandBudapest, date: new Date("2024-02-10"), noteUtilisateur: 8,   termine: true  },
    { utilisateurId: claire, filmId: parasite,     date: new Date("2024-02-20"), noteUtilisateur: 7,    termine: false },
    { utilisateurId: david, filmId: oldboy,        date: new Date("2024-01-05"), noteUtilisateur: 9,    termine: true  },
    { utilisateurId: david, filmId: parasite,      date: new Date("2024-01-25"), noteUtilisateur: 10,   termine: true  },
    { utilisateurId: david, filmId: darkKnight,    date: new Date("2024-03-10"), noteUtilisateur: 9,    termine: true  },
    { utilisateurId: emma,  filmId: madMax,        date: new Date("2024-02-28"), noteUtilisateur: 8,    termine: true  },
    { utilisateurId: emma,  filmId: inception,     date: new Date("2024-03-05"), noteUtilisateur: null, termine: false },
])

console.log("Database seeded successfully")

await client.close()
