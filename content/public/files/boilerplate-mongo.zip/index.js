import { MongoClient } from "mongodb";

const uri = "mongodb://localhost:27017";

const client = new MongoClient(uri);

await client.connect()
console.log("Connected successfully to server")
const db = client.db("streaming")

const films = db.collection("films")
const result = await films.find({}).toArray()
console.log(result)

await client.close()
