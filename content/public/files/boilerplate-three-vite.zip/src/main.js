import * as THREE from "three";

// Create scene, camera, and renderer
const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  0.1,
  1000
);

const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement); // On ajoute l'élément DOM du renderer à la page HTML

// Create a cube
const geometry = new THREE.BoxGeometry(1, 1, 1); // Create the geometry of the cube
const material = new THREE.MeshStandardMaterial({ color: 0x00ff00 }); // Create the material of the cube
const cube = new THREE.Mesh(geometry, material); // Create the object of the cube with the geometry and material
scene.add(cube); // Add cube to the scene

cube.position.x = 0; // Set the position of the cube
camera.position.z = 5; // Set the position of the camera

// Create a light
const light = new THREE.DirectionalLight(0xffffff, 5); // Create the light
light.position.set(1, 2, 10);// Set the position of the light
light.target = cube; // Set the target of the light to the cube
scene.add(light); // Add the light to the scene

let lastFrameTime = 0;

// Animation loop, executed every frame
function animate(timeElapsedSinceBeginning) {
  // Check how much time has passed since the last frame
  const timeElapsedSinceLastFrame = (timeElapsedSinceBeginning - lastFrameTime) / 1000; // Convert to seconds
  lastFrameTime = timeElapsedSinceBeginning;

  cube.position.x += 0.4 * timeElapsedSinceLastFrame; // Move cube in the x direction
  cube.rotation.y += 0.4 * timeElapsedSinceLastFrame; // Rotate cube in the y axis

  if(cube.position.x > 4) cube.position.x = -4; // Reset cube position if it goes beyond the screen

  renderer.render(scene, camera); // Render the scene
}

// Ask the browser to call the animate function every frame
renderer.setAnimationLoop(animate);
