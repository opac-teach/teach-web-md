#ifndef _VOITURE_H
#define _VOITURE_H

#include <string>

class Voiture
{
private:
    std::string marque;
    int annee;

public:
    Voiture();

    Voiture(const Voiture &v);
    Voiture(std::string m, int a);
    ~Voiture();

    std::string getMarque();

    void setMarque(const std::string &m);
    int getAnnee();

    void setAnnee(const int &a);
    void afficherInfos();
};

#endif
