#include <iostream>
#include "Voiture.hpp"

int main()
{
    Voiture v1 = Voiture("Toyota", 2001);
    v1.afficherInfos();

    Voiture *v2 = new Voiture();
    v2->setAnnee(2002);
    v2->setMarque("Renault");
    v2->afficherInfos();

    delete v2; // suppression de l'objet alloué, appel du destructeur

    if (true)
    { // Nouveau bloc
        Voiture v3;
    } // on quitte le bloc, v2 disparait, destructeur appelé

    Voiture v4 = Voiture(v1);
    // Programme terminé, destructeur appelé
}