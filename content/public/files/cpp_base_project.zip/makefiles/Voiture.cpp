#include <iostream>
#include <string>
#include "Voiture.hpp"

Voiture::Voiture()
{
    std::cout << "Creation de la voiture " << std::endl;
}

Voiture::Voiture(const Voiture &v) : marque(v.marque), annee(v.annee)
{
}

Voiture::Voiture(std::string m, int a)
{
    marque = m;
    annee = a;
}

Voiture::~Voiture()
{
    std::cout << "Destruction de la voiture " << marque << std::endl;
}

std::string Voiture::getMarque()
{
    return marque;
}

void Voiture::setMarque(const std::string &m)
{
    marque = m;
}

int Voiture::getAnnee()
{
    return annee;
}

void Voiture::setAnnee(const int &a)
{
    annee = a;
}

void Voiture::afficherInfos()
{
    std::cout << "Marque: " << marque << ", Annee: " << annee << std::endl;
}