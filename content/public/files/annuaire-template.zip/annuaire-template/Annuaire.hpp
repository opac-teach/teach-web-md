#ifndef _ANNUAIRE_H
#define _ANNUAIRE_H

#include <string>
#include <map>

class Annuaire
{
public:
    void add(const std::string &nom, const std::string &numero);
};

#endif
